insert into usuarios_aplicacion values (1, 'jorge','robalito','111',CURRENT_TIMESTAMP(),'M','1112223');
insert into usuarios_aplicacion values (2, 'chompiras','saavedra','222',CURRENT_TIMESTAMP(),'F','2223334');
insert into usuarios_aplicacion values (3, 'enrique','faundez','333',CURRENT_TIMESTAMP(),'M','3334445');
insert into usuarios_aplicacion values (4, 'gustavo','peña','444',CURRENT_TIMESTAMP(),'M','4445556');
insert into usuarios_aplicacion values (5, 'claudio','diaz','555',CURRENT_TIMESTAMP(),'M','5556667');
insert into usuarios_aplicacion values (6, 'elisa','perez','666',CURRENT_TIMESTAMP(),'F','6667778');
insert into usuarios_aplicacion values (7, 'viviana','elgueta','777',CURRENT_TIMESTAMP(),'F','7778889');
insert into usuarios_aplicacion values (8, 'mario','elgueta','888',CURRENT_TIMESTAMP(),'M','8889990');

insert into ingreso_usuario values (21, 1,CURRENT_TIMESTAMP());
insert into ingreso_usuario values (20, 5,CURRENT_TIMESTAMP());
insert into ingreso_usuario values (22, 7,CURRENT_TIMESTAMP());
insert into ingreso_usuario values (24, 8,CURRENT_TIMESTAMP());
insert into ingreso_usuario values (23, 2,CURRENT_TIMESTAMP());
insert into ingreso_usuario values (25, 4,CURRENT_TIMESTAMP());
insert into ingreso_usuario values (26, 3,CURRENT_TIMESTAMP());
insert into ingreso_usuario values (27, 6,CURRENT_TIMESTAMP());

CREATE TABLE Contactos (id_contacto int, id_usuario int, telefono int, correo varchar(50) 
);
insert into Contactos values (230, 2, '2223334','c.saavedra@dfg.cl');
insert into Contactos values (231, 3, '3334445','e.faundez@sgk.cl');
insert into Contactos values (232, 1, '1112223','j.robalito@com.cl');
insert into Contactos values (233, 4, '4445556','g.peña@sok.cl');
insert into Contactos values (234, 5, '5556667','c.diaz@tlc.cl');
insert into Contactos values (235, 6, '6667778','e.perez@cct.cl');
insert into Contactos values (236, 7, '7778889','v.elegueta@mac.cl');
insert into Contactos values (237, 8, '8889990','m.elgueta@tok.cl');
